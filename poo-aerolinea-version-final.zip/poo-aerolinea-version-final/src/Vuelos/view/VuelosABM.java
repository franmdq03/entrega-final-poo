package Vuelos.view;

import Vuelos.controller.VueloController;
import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.VueloDao;
import Vuelos.model.repository.VueloDaoImpl;
import java.awt.Color;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VuelosABM extends javax.swing.JFrame {

    private VueloController vueloController;

    public VuelosABM(VueloController vueloController) {
        initComponents();
        setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
        getContentPane().setBackground(Color.CYAN);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.vueloController = vueloController;
        mostrarVuelos();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombreAerolinea = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableVuelos = new javax.swing.JTable();
        btnAgregarVuelo = new javax.swing.JButton();
        btnModificarVuelo = new javax.swing.JButton();
        btnBorrarVuelo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNombreAerolinea.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreAerolinea.setText("NOMBRE AEROLINEA ");

        tableVuelos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nro Vuelo", "Aeropuerto Salida", "Aeropuerto Llegada", "Hora Salida", "Hora Llegada", "Fecha Salida", "Fecha Llegada"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableVuelos.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tableVuelos);
        if (tableVuelos.getColumnModel().getColumnCount() > 0) {
            tableVuelos.getColumnModel().getColumn(0).setResizable(false);
            tableVuelos.getColumnModel().getColumn(1).setResizable(false);
            tableVuelos.getColumnModel().getColumn(2).setResizable(false);
            tableVuelos.getColumnModel().getColumn(3).setResizable(false);
            tableVuelos.getColumnModel().getColumn(6).setResizable(false);
        }

        btnAgregarVuelo.setText("Añadir");
        btnAgregarVuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarVueloActionPerformed(evt);
            }
        });

        btnModificarVuelo.setText("Modificar");
        btnModificarVuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarVueloActionPerformed(evt);
            }
        });

        btnBorrarVuelo.setText("Borrar");
        btnBorrarVuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarVueloActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNombreAerolinea, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAgregarVuelo)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificarVuelo)
                        .addGap(18, 18, 18)
                        .addComponent(btnBorrarVuelo)
                        .addGap(0, 1165, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNombreAerolinea)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregarVuelo)
                    .addComponent(btnModificarVuelo)
                    .addComponent(btnBorrarVuelo))
                .addContainerGap(107, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarVueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarVueloActionPerformed
        VuelosAñadir ventanaAñadir = new VuelosAñadir(vueloController, this);
        ventanaAñadir.setVisible(true);
    }//GEN-LAST:event_btnAgregarVueloActionPerformed

    private void btnBorrarVueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarVueloActionPerformed
        int selectedRow = tableVuelos.getSelectedRow();
        if (selectedRow >= 0) {
            int idVuelo = (int) tableVuelos.getValueAt(selectedRow, 0); // Suponiendo que el ID está en la primera columna
            try {
                vueloController.removeVuelo(idVuelo);
                mostrarVuelos(); // Método para actualizar la tabla después de eliminar
                JOptionPane.showMessageDialog(this, "Vuelo eliminado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (IllegalStateException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Ocurrió un error inesperado al eliminar el vuelo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona un vuelo para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnBorrarVueloActionPerformed

    private void btnModificarVueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarVueloActionPerformed
        int filaSeleccionada = tableVuelos.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un vuelo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int idVuelo = (int) tableVuelos.getModel().getValueAt(filaSeleccionada, 0);
        Vuelo vueloExistente = vueloController.searchVuelo(idVuelo);
        VueloModificar vueloModificar = new VueloModificar(vueloController, this, vueloExistente, vueloExistente.getNroVuelo());
        vueloModificar.setVisible(true);
    }//GEN-LAST:event_btnModificarVueloActionPerformed

    public void mostrarVuelos() {
        List<Vuelo> vuelos = vueloController.listVuelos();
        // Ordenar la lista de vuelos por fecha de salida
        vuelos.sort(Comparator.comparing(Vuelo::getFechaSalida));

        DefaultTableModel model = (DefaultTableModel) tableVuelos.getModel();
        model.setRowCount(0);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");

        for (Vuelo vuelo : vuelos) {
            model.addRow(new Object[]{
                vuelo.getIdVuelo(),
                vuelo.getNroVuelo(),
                vuelo.getAeropuertoSalida(),
                vuelo.getAeropuertoLlegada(),
                vuelo.getHoraSalida().toString(),
                vuelo.getHoraLlegada().toString(),
                vuelo.getFechaSalida().format(formatter),
                vuelo.getFechaLlegada().format(formatter)
            });
        }

        // Ajustar el ancho de la columna de ID solo una vez, fuera del bucle
        tableVuelos.getColumnModel().getColumn(0).setMinWidth(0);
        tableVuelos.getColumnModel().getColumn(0).setMaxWidth(0);
        tableVuelos.getColumnModel().getColumn(0).setWidth(0);
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                VueloDao vueloDao = new VueloDaoImpl();
                VueloController vueloController = new VueloController(vueloDao);
                new VuelosABM(vueloController).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarVuelo;
    private javax.swing.JButton btnBorrarVuelo;
    private javax.swing.JButton btnModificarVuelo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNombreAerolinea;
    private javax.swing.JTable tableVuelos;
    // End of variables declaration//GEN-END:variables
}
