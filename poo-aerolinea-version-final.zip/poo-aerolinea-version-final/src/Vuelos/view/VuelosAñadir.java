package Vuelos.view;

import Vuelos.controller.VueloController;
import java.awt.Color;
import java.time.LocalDate;
import java.time.LocalTime;
import javax.swing.JFrame;

/**
 *
 * @author usuario
 */
public class VuelosAñadir extends javax.swing.JFrame {

    private final VueloController controladora;
    private VuelosABM vueloAbm = null;

    public VuelosAñadir(VueloController vuelocontroller, VuelosABM vueloAbm) {
        initComponents();
        // Establecer el tamaño de la ventana
        setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize()); // Usa el tamaño de pantalla completo
        // Cambiar el color de fondo
        getContentPane().setBackground(Color.CYAN);  // Puedes elegir el color que desees
        // Establecer la acción de cerrar cuando se presiona el botón de cerrar
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.controladora = vuelocontroller;
        this.vueloAbm = vueloAbm;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNroVuelo = new javax.swing.JLabel();
        lblAeroSalida = new javax.swing.JLabel();
        lblAeroLlegada = new javax.swing.JLabel();
        lblHoraSalida = new javax.swing.JLabel();
        lblHoraLlegada = new javax.swing.JLabel();
        lblFechaSalida = new javax.swing.JLabel();
        lblFechaLlegada = new javax.swing.JLabel();
        txtNroVuelo = new javax.swing.JTextField();
        txtAeroSalida = new javax.swing.JTextField();
        txtAeroLlegada = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        ftxtHoraSalida = new javax.swing.JFormattedTextField();
        ftxtHoraLlegada = new javax.swing.JFormattedTextField();
        ftxtFechaSalida = new javax.swing.JFormattedTextField();
        ftxtFechaLlegada = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNroVuelo.setText("Numero de vuelo:");

        lblAeroSalida.setText("Aeropuerto de salida:");

        lblAeroLlegada.setText("Aeropuerto de llegada:");

        lblHoraSalida.setText("Hora de salida:");

        lblHoraLlegada.setText("Hora de llegada:");

        lblFechaSalida.setText("Fecha de salida:");

        lblFechaLlegada.setText("Fecha de llegada:");

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        ftxtHoraSalida.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT))));

        ftxtHoraLlegada.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT))));

        ftxtFechaSalida.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT))));

        ftxtFechaLlegada.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT))));

        jLabel1.setText("hh:mm");

        jLabel2.setText("hh:mm");

        jLabel3.setText("dd/mm/aa");

        jLabel4.setText("dd/mm/aa");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblNroVuelo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAeroSalida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAeroLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHoraLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblFechaSalida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblFechaLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHoraSalida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(79, 79, 79)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtAeroLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
                            .addComponent(txtAeroSalida)
                            .addComponent(ftxtHoraSalida)
                            .addComponent(ftxtHoraLlegada)
                            .addComponent(ftxtFechaSalida)
                            .addComponent(ftxtFechaLlegada)
                            .addComponent(txtNroVuelo))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnCancelar)))
                .addGap(18, 18, 18)
                .addComponent(btnAgregar)
                .addGap(17, 17, 17))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNroVuelo)
                    .addComponent(txtNroVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAeroSalida)
                    .addComponent(txtAeroSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAeroLlegada)
                    .addComponent(txtAeroLlegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHoraSalida)
                    .addComponent(ftxtHoraSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHoraLlegada)
                    .addComponent(ftxtHoraLlegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFechaSalida)
                    .addComponent(ftxtFechaSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFechaLlegada)
                    .addComponent(ftxtFechaLlegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregar)
                    .addComponent(btnCancelar))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String nroVuelo = txtNroVuelo.getText().trim();
        String aeroSalida = txtAeroSalida.getText().trim();
        String aeroLlegada = txtAeroLlegada.getText().trim();
        String horaSalidaStr = ftxtHoraSalida.getText().trim();
        String horaLlegadaStr = ftxtHoraLlegada.getText().trim();
        String fechaSalidaStr = ftxtFechaSalida.getText().trim();
        String fechaLlegadaStr = ftxtFechaLlegada.getText().trim();

        // Validar si algún campo está vacío
        if (nroVuelo.isEmpty() || aeroSalida.isEmpty() || aeroLlegada.isEmpty()
                || horaSalidaStr.isEmpty() || horaLlegadaStr.isEmpty()
                || fechaSalidaStr.isEmpty() || fechaLlegadaStr.isEmpty()) {

            // Mostrar mensaje de alerta
            javax.swing.JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios",
                    "Error", javax.swing.JOptionPane.WARNING_MESSAGE);
            return; // Salir del método si falta algún dato
        }

        try {
            // Divide la cadena de fecha y hora por "/" y ":"
            String[] fechaSalidaParts = fechaSalidaStr.split("/");
            String[] fechaLlegadaParts = fechaLlegadaStr.split("/");
            String[] horaSalidaParts = horaSalidaStr.split(":");
            String[] horaLlegadaParts = horaLlegadaStr.split(":");

            // Construir LocalDate a partir de las partes
            LocalDate fechaSalida = LocalDate.of(
                    Integer.parseInt(fechaSalidaParts[2]), // Año
                    Integer.parseInt(fechaSalidaParts[1]), // Mes
                    Integer.parseInt(fechaSalidaParts[0]) // Día
            );

            LocalDate fechaLlegada = LocalDate.of(
                    Integer.parseInt(fechaLlegadaParts[2]), // Año
                    Integer.parseInt(fechaLlegadaParts[1]), // Mes
                    Integer.parseInt(fechaLlegadaParts[0]) // Día
            );

            // Construir LocalTime a partir de las partes
            LocalTime horaSalida = LocalTime.of(
                    Integer.parseInt(horaSalidaParts[0]), // Hora
                    Integer.parseInt(horaSalidaParts[1]) // Minutos
            );

            LocalTime horaLlegada = LocalTime.of(
                    Integer.parseInt(horaLlegadaParts[0]), // Hora
                    Integer.parseInt(horaLlegadaParts[1]) // Minutos
            );

            // Llamar al método de la controladora para agregar el vuelo
            controladora.addVuelo(nroVuelo, aeroSalida, aeroLlegada, horaSalida, horaLlegada, fechaSalida, fechaLlegada);
            vueloAbm.mostrarVuelos();
            this.setVisible(false);

        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Formato de fecha o hora incorrecto. Formato requerido: dd/MM/aa y hh:mm",
                    "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            System.err.println("Error al configurar el Look and Feel: " + ex.getMessage());
            ex.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(() -> {
            try {
                VueloController vueloController = new VueloController();
                VuelosABM vuelosAbm = new VuelosABM(vueloController);
                new VuelosAñadir(vueloController, vuelosAbm).setVisible(true);
            } catch (Exception e) {
                System.err.println("Error al iniciar la aplicación: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JFormattedTextField ftxtFechaLlegada;
    private javax.swing.JFormattedTextField ftxtFechaSalida;
    private javax.swing.JFormattedTextField ftxtHoraLlegada;
    private javax.swing.JFormattedTextField ftxtHoraSalida;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblAeroLlegada;
    private javax.swing.JLabel lblAeroSalida;
    private javax.swing.JLabel lblFechaLlegada;
    private javax.swing.JLabel lblFechaSalida;
    private javax.swing.JLabel lblHoraLlegada;
    private javax.swing.JLabel lblHoraSalida;
    private javax.swing.JLabel lblNroVuelo;
    private javax.swing.JTextField txtAeroLlegada;
    private javax.swing.JTextField txtAeroSalida;
    private javax.swing.JTextField txtNroVuelo;
    // End of variables declaration//GEN-END:variables

}
