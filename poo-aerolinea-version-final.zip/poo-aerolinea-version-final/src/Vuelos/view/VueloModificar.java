package Vuelos.view;

import Vuelos.controller.VueloController;
import Vuelos.model.entity.Vuelo;
import java.awt.Color;
import java.time.LocalDate;
import java.time.LocalTime;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class VueloModificar extends javax.swing.JFrame {

    private final VueloController controller;
    private VuelosABM vuelosAbm;
    public Vuelo vueloExistente;
    public String nroVuelo;

    public VueloModificar(VueloController controller, VuelosABM vuelosAbm, Vuelo vueloExistente, String nroVuelo) {
        initComponents();
        setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
        getContentPane().setBackground(Color.CYAN);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.controller = controller;
        this.vuelosAbm = vuelosAbm;
        this.vueloExistente = vueloExistente;
        this.nroVuelo = nroVuelo;
        cargarDatosVuelo(vueloExistente);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNroVuelo = new javax.swing.JTextField();
        lblNroVuelo = new javax.swing.JLabel();
        lblAeroSalida = new javax.swing.JLabel();
        lblAeroLlegada = new javax.swing.JLabel();
        lblHoraSalida = new javax.swing.JLabel();
        lblHoraLlegada = new javax.swing.JLabel();
        lblFechaSalida = new javax.swing.JLabel();
        lblFechaLlegada = new javax.swing.JLabel();
        txtAeroSalida = new javax.swing.JTextField();
        txtAeroLlegada = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        ftxtHoraSalida = new javax.swing.JFormattedTextField();
        ftxtHoraLlegada = new javax.swing.JFormattedTextField();
        ftxtFechaSalida = new javax.swing.JFormattedTextField();
        ftxtFechaLlegada = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtNroVuelo.setEditable(false);

        lblNroVuelo.setText("Numero de vuelo:");

        lblAeroSalida.setText("Aeropuerto de salida:");

        lblAeroLlegada.setText("Aeropuerto de llegada:");

        lblHoraSalida.setText("Hora de salida:");

        lblHoraLlegada.setText("Hora de llegada:");

        lblFechaSalida.setText("Fecha de salida:");

        lblFechaLlegada.setText("Fecha de llegada:");

        txtAeroSalida.setEditable(false);

        txtAeroLlegada.setEditable(false);
        txtAeroLlegada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAeroLlegadaActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        ftxtHoraSalida.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT))));

        ftxtHoraLlegada.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT))));
        ftxtHoraLlegada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftxtHoraLlegadaActionPerformed(evt);
            }
        });

        ftxtFechaSalida.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT))));

        ftxtFechaLlegada.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT))));

        jLabel1.setText("hh:mm");

        jLabel2.setText("hh:mm");

        jLabel3.setText("dd/mm/aa");

        jLabel4.setText("dd/mm/aa");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(lblFechaLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblFechaSalida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHoraLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHoraSalida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAeroLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAeroSalida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblNroVuelo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtNroVuelo)
                    .addComponent(txtAeroSalida)
                    .addComponent(txtAeroLlegada)
                    .addComponent(ftxtHoraSalida)
                    .addComponent(ftxtHoraLlegada)
                    .addComponent(ftxtFechaSalida)
                    .addComponent(ftxtFechaLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnGuardar)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNroVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNroVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtAeroSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAeroSalida))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtAeroLlegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAeroLlegada))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ftxtHoraSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblHoraSalida)
                            .addComponent(jLabel1))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ftxtHoraLlegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblHoraLlegada)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addGap(3, 3, 3))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ftxtFechaSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblFechaSalida))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ftxtFechaLlegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblFechaLlegada))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnCancelar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ftxtHoraLlegadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftxtHoraLlegadaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ftxtHoraLlegadaActionPerformed

    private void txtAeroLlegadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAeroLlegadaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAeroLlegadaActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro de que desea cancelar la edición?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try {
            // Validamos y convertimos las fechas y horas de salida/llegada
            LocalDate fechaSalida = parsearFecha(ftxtFechaSalida.getText().trim(), vueloExistente.getFechaSalida());
            LocalDate fechaLlegada = parsearFecha(ftxtFechaLlegada.getText().trim(), vueloExistente.getFechaLlegada());
            LocalTime horaSalida = parsearHora(ftxtHoraSalida.getText().trim(), vueloExistente.getHoraSalida());
            LocalTime horaLlegada = parsearHora(ftxtHoraLlegada.getText().trim(), vueloExistente.getHoraLlegada());

            // Actualizamos el vuelo con los nuevos valores
            controller.updateVuelo(vueloExistente.getIdVuelo(), horaSalida, horaLlegada, fechaSalida, fechaLlegada);

            // Refrescamos la vista principal y cerramos esta ventana
            vuelosAbm.mostrarVuelos();
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al guardar el vuelo: " + e.getMessage());
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private LocalDate parsearFecha(String fechaStr, LocalDate fechaActual) {
        if (!fechaStr.isEmpty() && !fechaStr.equals(fechaActual.toString())) {
            String[] partesFecha = fechaStr.split("/");
            return LocalDate.of(
                    Integer.parseInt(partesFecha[2]),
                    Integer.parseInt(partesFecha[1]),
                    Integer.parseInt(partesFecha[0])
            );
        }
        return fechaActual;
    }

    private LocalTime parsearHora(String horaStr, LocalTime horaActual) {
        if (!horaStr.isEmpty() && !horaStr.equals(horaActual.toString())) {
            String[] partesHora = horaStr.split(":");
            return LocalTime.of(
                    Integer.parseInt(partesHora[0]),
                    Integer.parseInt(partesHora[1])
            );
        }
        return horaActual;
    }

    public void cargarDatosVuelo(Vuelo vueloExistente) {
        txtNroVuelo.setText(vueloExistente.getNroVuelo());
        txtAeroSalida.setText(vueloExistente.getAeropuertoSalida());
        txtAeroLlegada.setText(vueloExistente.getAeropuertoLlegada());
        ftxtHoraSalida.setText(vueloExistente.getHoraSalida().toString());
        ftxtHoraLlegada.setText(vueloExistente.getHoraLlegada().toString());
        ftxtFechaSalida.setText(vueloExistente.getFechaSalida().toString());
        ftxtFechaLlegada.setText(vueloExistente.getFechaLlegada().toString());

    }

    public void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                VueloController vueloController = new VueloController();
                VuelosABM vuelosAbm = new VuelosABM(vueloController);
                Vuelo vueloexistente = controller.searchVueloNroVuelo(nroVuelo);
                new VueloModificar(vueloController, vuelosAbm, vueloexistente, vueloexistente.getNroVuelo()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JFormattedTextField ftxtFechaLlegada;
    private javax.swing.JFormattedTextField ftxtFechaSalida;
    private javax.swing.JFormattedTextField ftxtHoraLlegada;
    private javax.swing.JFormattedTextField ftxtHoraSalida;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblAeroLlegada;
    private javax.swing.JLabel lblAeroSalida;
    private javax.swing.JLabel lblFechaLlegada;
    private javax.swing.JLabel lblFechaSalida;
    private javax.swing.JLabel lblHoraLlegada;
    private javax.swing.JLabel lblHoraSalida;
    private javax.swing.JLabel lblNroVuelo;
    private javax.swing.JTextField txtAeroLlegada;
    private javax.swing.JTextField txtAeroSalida;
    private javax.swing.JTextField txtNroVuelo;
    // End of variables declaration//GEN-END:variables
}
