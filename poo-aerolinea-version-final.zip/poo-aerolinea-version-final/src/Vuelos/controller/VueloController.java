package Vuelos.controller;

import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.VueloDao;
import Vuelos.model.repository.VueloDaoImpl;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * Controladora que gestiona las operaciones relacionadas con los vuelos.
 * Proporciona métodos para agregar, eliminar, buscar, actualizar y listar
 * vuelos.
 */
public class VueloController {

    private VueloDao vueloDao;

    /**
     * Constructor que inicializa la controladora con una implementación
     * personalizada de VueloDao.
     *
     * @param vueloDao instancia de la interfaz {@link VueloDao} para
     * interactuar con los datos de vuelos.
     */
    public VueloController(VueloDao vueloDao) {
        this.vueloDao = vueloDao;
    }

    /**
     * Constructor por defecto que inicializa la controladora con una
     * implementación por defecto de {@link VueloDaoImpl}.
     */
    public VueloController() {
        this.vueloDao = new VueloDaoImpl();
    }

    /**
     * Agrega un nuevo vuelo al sistema.
     *
     * @param nroVuelo número del vuelo.
     * @param aeroSalida aeropuerto de salida.
     * @param aeroLlegada aeropuerto de llegada.
     * @param horaSalida hora de salida del vuelo.
     * @param horaLlegada hora de llegada del vuelo.
     * @param fechaSalida fecha de salida del vuelo.
     * @param fechaLlegada fecha de llegada del vuelo.
     */
    public void addVuelo(String nroVuelo, String aeroSalida, String aeroLlegada, LocalTime horaSalida, LocalTime horaLlegada, LocalDate fechaSalida, LocalDate fechaLlegada) {
        Vuelo nuevoVuelo = new Vuelo(nroVuelo, horaSalida, horaLlegada, fechaSalida, fechaLlegada, aeroSalida, aeroLlegada);
        vueloDao.createVuelo(nuevoVuelo);
    }

    /**
     * Elimina un vuelo por su ID.
     *
     * @param idVuelo el identificador único del vuelo a eliminar.
     */
    public void removeVuelo(int idVuelo) {
        try {
            vueloDao.deleteVuelo(idVuelo);
        } catch (IllegalStateException e) {
            throw e; // Se propaga para ser manejada en la vista
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error inesperado al eliminar el vuelo.", e);
        }
    }

    /**
     * Busca un vuelo por su número de vuelo.
     *
     * @param nroVuelo el número del vuelo a buscar.
     * @return el vuelo encontrado, o {@code null} si no existe.
     */
    public Vuelo searchVueloNroVuelo(String nroVuelo) {
        return vueloDao.searchVueloNro(nroVuelo);
    }

    /**
     * Busca un vuelo por su ID.
     *
     * @param idVuelo el identificador único del vuelo a buscar.
     * @return el vuelo encontrado, o {@code null} si no existe.
     */
    public Vuelo searchVuelo(int idVuelo) {
        return vueloDao.searchVuelo(idVuelo);
    }

    /**
     * Actualiza los datos de un vuelo existente.
     *
     * @param idVuelo el identificador único del vuelo a actualizar.
     * @param horaSalida nueva hora de salida del vuelo.
     * @param horaLlegada nueva hora de llegada del vuelo.
     * @param fechaSalida nueva fecha de salida del vuelo.
     * @param fechaLlegada nueva fecha de llegada del vuelo.
     */
    public void updateVuelo(int idVuelo, LocalTime horaSalida, LocalTime horaLlegada, LocalDate fechaSalida, LocalDate fechaLlegada) {
        Vuelo vueloExistente = vueloDao.searchVuelo(idVuelo);
        if (vueloExistente != null) {
            vueloExistente.setHoraSalida(horaSalida);
            vueloExistente.setHoraLlegada(horaLlegada);
            vueloExistente.setFechaSalida(fechaSalida);
            vueloExistente.setFechaLlegada(fechaLlegada);
            vueloDao.updateVuelo(vueloExistente, idVuelo);
        }
    }

    /**
     * Devuelve una lista de todos los vuelos disponibles.
     *
     * @return una lista de vuelos registrados en el sistema.
     */
    public List<Vuelo> listVuelos() {
        return vueloDao.readAll();
    }
}
