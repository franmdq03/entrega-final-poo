package Vuelos.model.repository;

import Vuelos.model.entity.Vuelo;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

public class VueloDaoImpl implements VueloDao {

    private EntityManagerFactory emf;
    private EntityManager em;

    public VueloDaoImpl() {
        this.emf = Persistence.createEntityManagerFactory("proyecto-final-vuelosPU");
        this.em = emf.createEntityManager();
    }

    @Override
    public void createVuelo(Vuelo vuelo) {
        try {
            em.getTransaction().begin();
            em.persist(vuelo);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void updateVuelo(Vuelo vuelo, int id) {
        try {
            em.getTransaction().begin();
            em.merge(vuelo);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    public boolean hasPasajerosAsociados(int idVuelo) {
        try {
            Long count = em.createQuery(
                    "SELECT COUNT(p) FROM Pasajero p WHERE p.vueloPasajero.idVuelo = :idVuelo", Long.class)
                    .setParameter("idVuelo", idVuelo)
                    .getSingleResult();
            return count > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean hasEmpleadosAsociados(int idVuelo) {
        try {
            Long count = em.createQuery("SELECT COUNT(e) FROM empleados e WHERE e.vuelo.id = :idVuelo", Long.class)
                    .setParameter("idVuelo", idVuelo)
                    .getSingleResult();
            return count > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void deleteVuelo(int idVuelo) {
        if (hasPasajerosAsociados(idVuelo)) {
        throw new IllegalStateException("No se puede eliminar debido a que hay pasajeros o empleados asociados al vuelo.");
    }
    try {
        Vuelo vuelo = em.find(Vuelo.class, idVuelo);
        if (vuelo != null) {
            em.getTransaction().begin();
            em.remove(vuelo);
            em.getTransaction().commit();
        }
    } catch (Exception e) {
        e.printStackTrace();
        throw new RuntimeException("Error al intentar eliminar el vuelo.", e);
    }
    }

    @Override
    public Vuelo searchVuelo(int id) {
        Vuelo vuelo = null;
        try {
            vuelo = em.find(Vuelo.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vuelo;
    }

    public Vuelo searchVueloNro(String nroVuelo) {
        try {
            return (Vuelo) em.createQuery("SELECT v FROM Vuelo v WHERE v.nroVuelo = :nroVuelo")
                    .setParameter("nroVuelo", nroVuelo)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null; // O algún manejo alternativo
        }
    }

    @Override
    public List<Vuelo> readAll() {
        List<Vuelo> vuelos = null;
        try {
            vuelos = em.createQuery("SELECT v FROM Vuelo v", Vuelo.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vuelos;
    }

    public void close() {
        if (em.isOpen()) {
            em.close();
        }
        if (emf.isOpen()) {
            emf.close();
        }
    }
}
