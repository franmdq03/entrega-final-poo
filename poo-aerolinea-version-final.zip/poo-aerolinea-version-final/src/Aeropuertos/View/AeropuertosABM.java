package Aeropuertos.View;

import Aeropuertos.Controller.AeropuertoController;
import Aeropuertos.Model.Entity.Aeropuerto;
import Aeropuertos.Model.Repository.AeropuertoDaoImpl;
import Intro.View.Intro;
import java.awt.Color;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AeropuertosABM extends javax.swing.JFrame {

    private AeropuertoController aeropuertoController;

    public AeropuertosABM(AeropuertoController aeropuertoController) {
        initComponents();
        setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
        getContentPane().setBackground(Color.CYAN);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.aeropuertoController = aeropuertoController;
        mostrarAeropuertos();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombreAerolinea = new javax.swing.JLabel();
        btnAgregarAeropuerto = new javax.swing.JButton();
        btnModificarAeropuerto = new javax.swing.JButton();
        btnBorrarAeropuerto = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableAeropuertos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNombreAerolinea.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreAerolinea.setText("NOMBRE AEROLINEA ");

        btnAgregarAeropuerto.setText("Añadir");
        btnAgregarAeropuerto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarAeropuertoActionPerformed(evt);
            }
        });

        btnModificarAeropuerto.setText("Modificar");
        btnModificarAeropuerto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarAeropuertoActionPerformed(evt);
            }
        });

        btnBorrarAeropuerto.setText("Borrar");
        btnBorrarAeropuerto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarAeropuertoActionPerformed(evt);
            }
        });

        tableAeropuertos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Nombre Aero", "Ciudad "
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tableAeropuertos);
        if (tableAeropuertos.getColumnModel().getColumnCount() > 0) {
            tableAeropuertos.getColumnModel().getColumn(0).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblNombreAerolinea, javax.swing.GroupLayout.DEFAULT_SIZE, 1345, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 872, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnAgregarAeropuerto)
                                .addGap(37, 37, 37)
                                .addComponent(btnModificarAeropuerto)
                                .addGap(34, 34, 34)
                                .addComponent(btnBorrarAeropuerto)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNombreAerolinea)
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregarAeropuerto)
                    .addComponent(btnModificarAeropuerto)
                    .addComponent(btnBorrarAeropuerto))
                .addGap(105, 105, 105))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarAeropuertoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarAeropuertoActionPerformed
        AeropuertosAñadir ventanaAñadir = new AeropuertosAñadir(aeropuertoController, this);
        ventanaAñadir.setVisible(true);
    }//GEN-LAST:event_btnAgregarAeropuertoActionPerformed

    private void btnModificarAeropuertoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarAeropuertoActionPerformed
        int filaSeleccionada = tableAeropuertos.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un aeropuerto.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int idAeropuerto = (int) tableAeropuertos.getModel().getValueAt(filaSeleccionada, 0);
        Aeropuerto aeropuertoExistente = aeropuertoController.searchAeropuerto(idAeropuerto);
        AeropuertoModificar aeropuertoModificar = new AeropuertoModificar(aeropuertoController, this, aeropuertoExistente, aeropuertoExistente.getNombre());
        aeropuertoModificar.setVisible(true);
    }//GEN-LAST:event_btnModificarAeropuertoActionPerformed

    private void btnBorrarAeropuertoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarAeropuertoActionPerformed
        int filaSeleccionada = tableAeropuertos.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un aeropuerto.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int idAeropuerto = (int) tableAeropuertos.getModel().getValueAt(filaSeleccionada, 0);
        aeropuertoController.removeAeropuerto(idAeropuerto);
        mostrarAeropuertos();
    }//GEN-LAST:event_btnBorrarAeropuertoActionPerformed

    public void mostrarAeropuertos() {
        List<Aeropuerto> aeropuertos = aeropuertoController.listAeropuertos();
        DefaultTableModel model = (DefaultTableModel) tableAeropuertos.getModel();
        model.setRowCount(0);

        for (Aeropuerto aeropuerto : aeropuertos) {
            model.addRow(new Object[]{
                aeropuerto.getId(),
                aeropuerto.getNombre(),
                aeropuerto.getCiudad()
            });
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                AeropuertoDaoImpl aeropuertoDaoImpl = new AeropuertoDaoImpl();
                AeropuertoController aeropuertoController = new AeropuertoController(aeropuertoDaoImpl);
                new AeropuertosABM(aeropuertoController).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarAeropuerto;
    private javax.swing.JButton btnBorrarAeropuerto;
    private javax.swing.JButton btnModificarAeropuerto;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNombreAerolinea;
    private javax.swing.JTable tableAeropuertos;
    // End of variables declaration//GEN-END:variables
}
