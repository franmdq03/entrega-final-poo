package Aeropuertos.Model.Repository;

import Aeropuertos.Model.Entity.Aeropuerto;
import java.util.List;

public interface AeropuertoDao {

    public void createAeropuerto(Aeropuerto aeropuerto);

    public void updateAeropuerto(Aeropuerto aeropuerto, int id);

    public void deleteAeropuerto(int id);

    public Aeropuerto searchAeropuertoByName(String nombre);

    public Aeropuerto searchAeropuerto(int id);

    public List<Aeropuerto> readAll();
}
