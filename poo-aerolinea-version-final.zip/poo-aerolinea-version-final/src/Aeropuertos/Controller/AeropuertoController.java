package Aeropuertos.Controller;

import Aeropuertos.Model.Entity.Aeropuerto;
import Aeropuertos.Model.Repository.AeropuertoDao;
import Aeropuertos.Model.Repository.AeropuertoDaoImpl;
import java.util.List;

/**
 * Controladora que gestiona las operaciones relacionadas con los aeropuertos.
 * Permite agregar, eliminar, buscar, actualizar y listar aeropuertos.
 */
public class AeropuertoController {

    private AeropuertoDao aeropuertoDao;
    private AeropuertoDaoImpl aeropuertoDaoImpl;

    /**
     * Constructor que inicializa la controladora con una implementación personalizada de {@link AeropuertoDaoImpl}.
     *
     * @param aeropuertoDaoImpl instancia de {@link AeropuertoDaoImpl} para gestionar los aeropuertos.
     */
    public AeropuertoController(AeropuertoDaoImpl aeropuertoDaoImpl) {
        this.aeropuertoDaoImpl = aeropuertoDaoImpl;
    }

    /**
     * Constructor por defecto.
     */
    public AeropuertoController() {
    }

    /**
     * Agrega un nuevo aeropuerto al sistema.
     *
     * @param nombre el nombre del aeropuerto.
     * @param ciudad la ciudad donde se encuentra el aeropuerto.
     */
    public void addAeropuerto(String nombre, String ciudad) {
        Aeropuerto nuevoAeropuerto = new Aeropuerto(nombre, ciudad);
        aeropuertoDaoImpl.createAeropuerto(nuevoAeropuerto);
    }

    /**
     * Elimina un aeropuerto del sistema usando su ID.
     *
     * @param id el identificador único del aeropuerto a eliminar.
     */
    public void removeAeropuerto(int id) {
        aeropuertoDaoImpl.deleteAeropuerto(id);
    }

    /**
     * Busca un aeropuerto por su nombre.
     *
     * @param nombreAeropuerto el nombre del aeropuerto a buscar.
     * @return el aeropuerto encontrado o {@code null} si no se encuentra.
     */
    public Aeropuerto searchAeropuertoNombre(String nombreAeropuerto) {
        return aeropuertoDaoImpl.searchAeropuertoByName(nombreAeropuerto);
    }

    /**
     * Busca un aeropuerto por su ID.
     *
     * @param id el identificador único del aeropuerto a buscar.
     * @return el aeropuerto encontrado o {@code null} si no se encuentra.
     */
    public Aeropuerto searchAeropuerto(int id) {
        return aeropuertoDaoImpl.searchAeropuerto(id);
    }

    /**
     * Actualiza los datos de un aeropuerto existente.
     *
     * @param id     el identificador único del aeropuerto a actualizar.
     * @param nombre el nuevo nombre del aeropuerto.
     * @param ciudad la nueva ciudad del aeropuerto.
     */
    public void updateAeropuerto(int id, String nombre, String ciudad) {
        Aeropuerto aeropuertoExistente = aeropuertoDaoImpl.searchAeropuerto(id);
        if (aeropuertoExistente != null) {
            aeropuertoExistente.setNombre(nombre);
            aeropuertoExistente.setCiudad(ciudad);
            aeropuertoDaoImpl.updateAeropuerto(aeropuertoExistente, id);
        }
    }

    /**
     * Devuelve una lista con todos los aeropuertos registrados en el sistema.
     *
     * @return una lista de aeropuertos.
     */
    public List<Aeropuerto> listAeropuertos() {
        return aeropuertoDaoImpl.readAll();
    }
}
