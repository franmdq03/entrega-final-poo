package Main;

import Aeropuertos.Controller.AeropuertoController;
import Aeropuertos.Model.Repository.AeropuertoDaoImpl;
import Aeropuertos.View.AeropuertosABM;
import Intro.View.Intro;
import Personas.Empleados.Controller.EmpleadoController;
import Personas.Empleados.Model.Repository.EmpleadoDaoImpl;
import Personas.Empleados.View.EmpleadoABM;
import Personas.Pasajeros.Controller.PasajeroController;
import Personas.Pasajeros.Model.Repository.PasajeroDaoImpl;
import Personas.Pasajeros.View.PasajeroABM;
import Vuelos.controller.VueloController;
import Vuelos.model.repository.VueloDaoImpl;
import Vuelos.view.VuelosABM;

public class ProyectoFinalProgramacion {

    public static void main(String[] args) {
    //Crear vuelo   
    VueloDaoImpl VueloDaoImpl = new VueloDaoImpl();
    VueloController controller = new VueloController(VueloDaoImpl);
    VuelosABM vuelosAbm = new VuelosABM(controller);
    
    //Crear pasajero
    PasajeroDaoImpl pasajeroDaoImpl = new PasajeroDaoImpl();
    PasajeroController pasajeroController = new PasajeroController(pasajeroDaoImpl,VueloDaoImpl);
    PasajeroABM pasajeroAbm = new PasajeroABM(pasajeroController, pasajeroDaoImpl, controller);
    
    //Crear aeropuerto
    AeropuertoDaoImpl aeropuertoDaoImpl = new AeropuertoDaoImpl();
    AeropuertoController aeropuertoController = new AeropuertoController(aeropuertoDaoImpl);
    AeropuertosABM aeropuertoABM = new AeropuertosABM(aeropuertoController);
    
    //Crear empleado
    EmpleadoDaoImpl empleadoDaoImpl = new EmpleadoDaoImpl();
    EmpleadoController empleadoController = new EmpleadoController(empleadoDaoImpl);
    EmpleadoABM empleadoAbm = new EmpleadoABM(empleadoDaoImpl, empleadoController);
    
    //Crear intro
    Intro intro = new Intro(vuelosAbm, pasajeroAbm, aeropuertoABM,empleadoAbm);
    intro.setVisible(true);
    }
}
