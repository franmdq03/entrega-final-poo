package Personas.Empleados.Controller;

import Personas.Empleados.Model.Entity.Empleado;
import Personas.Empleados.Model.Repository.EmpleadoDaoImpl;
import Vuelos.model.entity.Vuelo;
import java.util.List;

/**
 * Controladora que gestiona las operaciones relacionadas con los empleados.
 * Permite agregar, eliminar, actualizar y listar empleados, además de gestionar su relación con los vuelos asignados.
 */
public class EmpleadoController {

    private EmpleadoDaoImpl empleadoDaoImpl;

    /**
     * Constructor que inicializa la controladora con una implementación personalizada de {@link EmpleadoDaoImpl}.
     *
     * @param empleadoDaoImpl instancia de {@link EmpleadoDaoImpl} para gestionar los empleados.
     */
    public EmpleadoController(EmpleadoDaoImpl empleadoDaoImpl) {
        this.empleadoDaoImpl = empleadoDaoImpl;
    }

    /**
     * Constructor por defecto que inicializa la controladora con una implementación predeterminada de {@link EmpleadoDaoImpl}.
     */
    public EmpleadoController() {
        this.empleadoDaoImpl = new EmpleadoDaoImpl();
    }

    /**
     * Agrega un nuevo empleado al sistema.
     *
     * @param puestoDeTrabajo el puesto de trabajo del empleado.
     * @param vuelo           el vuelo asignado al empleado.
     * @param avion           el avión asignado al empleado.
     * @param nombre          el nombre del empleado.
     * @param apellido        el apellido del empleado.
     * @param dni             el DNI del empleado.
     */
    public void addEmpleado(String puestoDeTrabajo, Vuelo vuelo, String avion, String nombre, String apellido, long dni) {
        Empleado empleado = new Empleado(puestoDeTrabajo, vuelo, avion, nombre, apellido, dni);
        empleadoDaoImpl.createEmpleado(empleado);
    }

    /**
     * Elimina un empleado del sistema usando su ID.
     *
     * @param id el identificador único del empleado a eliminar.
     */
    public void deleteEmpleado(int id) {
        empleadoDaoImpl.deleteEmpleado(id);
    }

    /**
     * Actualiza los datos de un empleado existente.
     *
     * @param puestoDeTrabajo el nuevo puesto de trabajo del empleado.
     * @param vuelo           el nuevo vuelo asignado al empleado.
     * @param avion           el nuevo avión asignado al empleado.
     * @param id              el identificador único del empleado a actualizar.
     */
    public void updateEmpleado(String puestoDeTrabajo, Vuelo vuelo, String avion, int id) {
        Empleado empleadoExistente = empleadoDaoImpl.searchEmpleado(id);
        empleadoExistente.setVuelo(vuelo);
        empleadoExistente.setAvion(avion);

        empleadoDaoImpl.updateEmpleado(empleadoExistente, id);
    }

    /**
     * Devuelve una lista con todos los empleados registrados en el sistema.
     *
     * @return una lista de empleados.
     */
    public List<Empleado> listEmpleado() {
        List<Empleado> listaPasajeros = empleadoDaoImpl.readAll();
        return listaPasajeros;
    }
}
