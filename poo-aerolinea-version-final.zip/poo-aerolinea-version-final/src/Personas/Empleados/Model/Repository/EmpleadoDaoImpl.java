package Personas.Empleados.Model.Repository;

import Personas.Empleados.Model.Entity.Empleado;
import Personas.Pasajeros.Model.Entity.Pasajero;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author usuario
 */
public class EmpleadoDaoImpl implements EmpleadoDao {

    private EntityManagerFactory emf;
    private EntityManager em;

    public EmpleadoDaoImpl() {
        this.emf = Persistence.createEntityManagerFactory("proyecto-final-vuelosPU");
        this.em = emf.createEntityManager();
    }

    @Override
    public void createEmpleado(Empleado empleado) {
        EntityManager em = emf.createEntityManager(); // Crea un nuevo EntityManager
        try {
            em.getTransaction().begin(); // Inicia la transacción
            em.persist(empleado);
            em.getTransaction().commit(); // Finaliza la transacción
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Revierte la transacción si algo falla
            }
            e.printStackTrace();
        } finally {
            em.close(); // Asegúrate de cerrar el EntityManager
        }
    }

    @Override
    public void updateEmpleado(Empleado empleado, int id) {
        try {
            em.getTransaction().begin();
            Empleado existingEmpleado = em.find(Empleado.class, id);
            if (existingEmpleado != null) {
                existingEmpleado.setPuestoDeTrabajo(empleado.getPuestoDeTrabajo());
                existingEmpleado.setVuelo(empleado.getVuelo());
                existingEmpleado.setAvion(empleado.getAvion());
                em.merge(existingEmpleado);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteEmpleado(int id) {
        try {
            em.getTransaction().begin();
            Empleado empleado = em.find(Empleado.class, id);
            if (empleado != null) {
                em.remove(empleado);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Empleado searchEmpleado(int id) {
        Empleado empleado = null;
        try {
            empleado = em.find(Empleado.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return empleado;
    }

    @Override
    public List<Empleado> readAll() {
        List<Empleado> empleado = null;
        try {
            empleado = em.createQuery("SELECT e FROM Empleado e", Empleado.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return empleado;
    }

}
